/** @format */

// Example in HomePage.js
import React from "react";
import EmailSignup from "../components/ui/Global/EmailSignup";

function HomePage() {
	return (
		<div>
			
			<EmailSignup />
			
		</div>
	);
}

export default HomePage;
