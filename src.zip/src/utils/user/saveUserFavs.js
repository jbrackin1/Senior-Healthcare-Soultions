/** @format */
// import React from "react";

// const saveFavorites = async () => {
//   if (isLoggedIn) {
//     try {
//       await saveUserFavorites(favorites);
//     } catch (error) {
//       console.error("Failed to save favorites:", error);
//     }
//   }
// };
